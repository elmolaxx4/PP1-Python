@app.get("/saludo")  
async def saludo():
    return {"hola": "mundo"}


@app.put("/saludo/put")
async def put():
    return {"mensaje": "put"}


@app.post("/saludo/post")
async def post():
    return {"mensaje": "post"}


@app.delete("/saludo/delete")
async def delete():
    return {"mensaje": "delete"}